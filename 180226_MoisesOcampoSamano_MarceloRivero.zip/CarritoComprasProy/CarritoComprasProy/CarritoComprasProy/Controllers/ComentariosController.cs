﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CarritoComprasProy.Models;

namespace CarritoComprasProy.Controllers
{
    public class ComentariosController : Controller
    {
        private ProductoCatalogoContext dbContext = new ProductoCatalogoContext();

        // GET: Comentarios
        public ActionResult Index()
        {
            var commentariosProductos = dbContext.CommentariosProductos.Include(c => c.producto);
            return View(commentariosProductos.ToList());
        }


        public ActionResult CrearComentario(int skuId)
        {            
            return View();
        }


        public ActionResult GuardarComentario(ComentariosProducto comentariosProducto)
        {            
            try
            {
                string userId = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(User.Identity.Name);
                comentariosProducto.Usuario = userId;
                dbContext.CommentariosProductos.Add(comentariosProducto);
                dbContext.SaveChanges();
            }
            catch(Exception e)
            {
                return View("Error");
            }

            return RedirectToAction("Detalles", "Producto", new { id = comentariosProducto.SkuID });
        }
        

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                dbContext.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
