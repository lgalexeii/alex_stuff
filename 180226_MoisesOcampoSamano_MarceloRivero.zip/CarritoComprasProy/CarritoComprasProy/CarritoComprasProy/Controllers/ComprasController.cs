﻿using CarritoComprasProy.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CarritoComprasProy.Controllers
{
    public class ComprasController : Controller
    {

        private ProductoCatalogoContext dbContext = new ProductoCatalogoContext();
        // GET: Compras
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ComprarArticulo(int OrdenId, int skuId, int cantidad, string usuario, string titulo, decimal precio, int stock)
        {
            try
            {
                string userId = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(User.Identity.Name);
                ArticuloCarrito articuloCarrito = dbContext.ArticulosCarrito.Find(OrdenId);

                DetallesCarrito detallesCarrito = new DetallesCarrito();
                detallesCarrito.NumOrdenId = OrdenId;
                detallesCarrito.SkuID = skuId;
                detallesCarrito.Usuario = userId;
                detallesCarrito.cantidad = cantidad;
                detallesCarrito.Titulo = titulo;
                detallesCarrito.Precio = precio;
                detallesCarrito.Existencias = stock;
                detallesCarrito.Total = detallesCarrito.cantidad * detallesCarrito.Precio;
                return PartialView("ComprarArticulo", detallesCarrito);
            }
            catch (Exception e)
            {
                return View();
            }

        }

        public ActionResult EjecutaComprarArticulo(DetallesCarrito detallesCarrito)
        {
            try
            {

                if (detallesCarrito.CuponCompra==null || detallesCarrito.CuponCompra.Equals(""))
                {
                    ModelState.AddModelError("", "Por favor Teclee su cupon de compra." );
                    return View("ComprarArticulo", detallesCarrito);

                }

                if(detallesCarrito.cantidad > detallesCarrito.Existencias)
                {
                    ModelState.AddModelError("", "La cantidad debe ser menor que el numero de existencias. El stock Maximo es: "+ detallesCarrito.Existencias);
                    return View("ComprarArticulo", detallesCarrito);
                }

                if (detallesCarrito.cantidad <=0)
                {
                    ModelState.AddModelError("", "La cantidad no es valida");
                    return View("ComprarArticulo", detallesCarrito);
                }

                //Agrega articulo a las compras
                CompraUsuario compraUsuario = new CompraUsuario();
                compraUsuario.SkuID = detallesCarrito.SkuID;
                compraUsuario.Usuario = detallesCarrito.Usuario;
                compraUsuario.Cantidad = detallesCarrito.cantidad;
                compraUsuario.PrecioUnidad = detallesCarrito.Precio;
                compraUsuario.Total = compraUsuario.Cantidad * compraUsuario.PrecioUnidad;
                compraUsuario.CuponCompra = detallesCarrito.CuponCompra;
                compraUsuario.FechaCompra = DateTime.Now.ToString();
                dbContext.ComprasUsuario.Add(compraUsuario);

                //Elimina articulo del carrito de compras
                ArticuloCarrito articuloCarrito = dbContext.ArticulosCarrito.Find(detallesCarrito.NumOrdenId);
                dbContext.ArticulosCarrito.Remove(articuloCarrito);
                
                //Descuenta del inventario la compra
                Producto producto = dbContext.Productos.Find(detallesCarrito.SkuID);
                producto.Existencias = producto.Existencias - compraUsuario.Cantidad;
                dbContext.Entry(producto).CurrentValues.SetValues(producto);
                //dbContext.Productos.Add(producto);

                dbContext.SaveChanges();
                return RedirectToAction("_MostrarCompras");
            }
            catch (Exception e)
            {
                return View("Error");
            }

        }


        public ActionResult _MostrarCompras()
        {
            string userId = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(User.Identity.Name);
            var ComprasDetalle = (from compras in dbContext.ComprasUsuario
                                  join prod in dbContext.Productos on compras.SkuID equals prod.SkuID
                                  where compras.Usuario== userId
                                  select new
                                  {
                                      NumCompraId = compras.NumCompraId,
                                      SkuID = compras.SkuID,
                                      Usuario = compras.Usuario,
                                      Cantidad = compras.Cantidad,
                                      PrecioUnidad = compras.PrecioUnidad,
                                      Total = compras.Total,
                                      Titulo = prod.Titulo,
                                      FotoArchivo = prod.FotoArchivo,
                                      CuponCompra= compras.CuponCompra,
                                      FechaCompra=compras.FechaCompra

                                  });

            List<CompraUsuarioDetalle> ListaComprasDetalle = new List<CompraUsuarioDetalle>();
            foreach (var compraDetalle in ComprasDetalle)
            {
                CompraUsuarioDetalle compraUsuarioDetalle = new CompraUsuarioDetalle();
                compraUsuarioDetalle.NumCompraId = compraDetalle.NumCompraId;
                compraUsuarioDetalle.SkuID = compraDetalle.SkuID;
                compraUsuarioDetalle.Usuario = compraDetalle.Usuario;
                compraUsuarioDetalle.Cantidad = compraDetalle.Cantidad;
                compraUsuarioDetalle.Titulo = compraDetalle.Titulo;
                compraUsuarioDetalle.PrecioUnidad = compraDetalle.PrecioUnidad;
                compraUsuarioDetalle.FotoArchivo = compraDetalle.FotoArchivo;
                compraUsuarioDetalle.Total = compraDetalle.Cantidad * compraDetalle.PrecioUnidad;
                compraUsuarioDetalle.CuponCompra = compraDetalle.CuponCompra;
                compraUsuarioDetalle.FechaCompra = compraDetalle.FechaCompra;
                ListaComprasDetalle.Add(compraUsuarioDetalle);
            }
            return PartialView("_MostrarCompras", ListaComprasDetalle);
        }

        public ActionResult ComprasUsuario()
        {
            return View();
        }
    }
}