﻿using CarritoComprasProy.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CarritoComprasProy.Controllers
{
    public class CarritoController : Controller
    {

        private ProductoCatalogoContext dbContext = new ProductoCatalogoContext();


        // GET: Carrito
        public ActionResult Index()
        {
            return View();
        }

        

        [Authorize]
        public ActionResult AgregarArticuloCarrito(int SkuId)
        {
            string userId;
            Producto producto = dbContext.Productos.Find(SkuId);
            List<ArticuloCarrito> ListaArticuloCarrito = (from art in dbContext.ArticulosCarrito
                                                          where art.SkuID == SkuId
                                                          select art).ToList();

            userId = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(User.Identity.Name);

            if (ListaArticuloCarrito.Count==0 && producto.Existencias>0)
            {
                ArticuloCarrito articuloCarritoAux = AsignaArticuloParaCarrito(SkuId, userId, producto);
                dbContext.ArticulosCarrito.Add(articuloCarritoAux);
                dbContext.SaveChanges();
            }
            else
            {
                return View("ArticuloExistente");
            }            
            return RedirectToAction("_MostrarCarritoDetalle");
        }

        public ActionResult QuitarArticuloCarrito(int NumOrdenId)
        {
            ArticuloCarrito articuloCarrito = dbContext.ArticulosCarrito.Find(NumOrdenId);
            dbContext.ArticulosCarrito.Remove(articuloCarrito);
            dbContext.SaveChanges();
            return RedirectToAction("_MostrarCarritoDetalle");
        }

        public ActionResult _MostrarCarrito()
        {
            string userId = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(User.Identity.Name);
            if(userId.Equals("") || userId == null)
            {
                return RedirectToAction("Login","Cuentas");
            }
            return RedirectToAction("_MostrarCarritoDetalle");
        }

        public ActionResult _MostrarCarritoDetalle()
        {
            string userId = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(User.Identity.Name);
            var DatosCarrito = (from artCarrito in dbContext.ArticulosCarrito
                                join prod in dbContext.Productos on artCarrito.SkuID equals prod.SkuID
                                where artCarrito.Usuario==userId
                                select new
                                {
                                    NumOrdenId = artCarrito.NumOrdenId,
                                    SkuID = artCarrito.SkuID,
                                    Usuario = artCarrito.Usuario,
                                    cantidad = artCarrito.cantidad,
                                    Titulo = prod.Titulo,
                                    Precio = prod.Precio,
                                    Existencias = prod.Existencias,
                                    FotoArchivo = prod.FotoArchivo
                                });

            List<DetallesCarrito> ListaDetallesCarrito = new List<DetallesCarrito>();
            foreach (var datoCarrito in DatosCarrito)
            {
                DetallesCarrito detallesCarrito = new DetallesCarrito();
                detallesCarrito.NumOrdenId = datoCarrito.NumOrdenId;
                detallesCarrito.SkuID = datoCarrito.SkuID;
                detallesCarrito.Usuario = datoCarrito.Usuario;
                detallesCarrito.cantidad = datoCarrito.cantidad;
                detallesCarrito.Titulo = datoCarrito.Titulo;
                detallesCarrito.Precio = datoCarrito.Precio;
                detallesCarrito.Existencias = datoCarrito.Existencias;
                detallesCarrito.FotoArchivo = datoCarrito.FotoArchivo;
                detallesCarrito.Total = detallesCarrito.cantidad * detallesCarrito.Precio;
                ListaDetallesCarrito.Add(detallesCarrito);
            }
            return PartialView("_MostrarCarritoDetalle", ListaDetallesCarrito);
        }

        private ArticuloCarrito AsignaArticuloParaCarrito(int SkuId, string usuario, Producto producto)
        {
            ArticuloCarrito articuloCarrito = new ArticuloCarrito();
            articuloCarrito.cantidad = 1;
            articuloCarrito.Usuario = usuario;
            articuloCarrito.SkuID = producto.SkuID;
            return articuloCarrito;
        }

    }
}
