﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CarritoComprasProy.Models;

namespace CarritoComprasProy.Controllers
{
    public class ProductoController : Controller
    {
        private ProductoCatalogoContext dbContext = new ProductoCatalogoContext();

        // GET: Producto
        public ActionResult Index()
        {
            return View("Index");
        }


        [ChildActionOnly]
        public ActionResult _GaleriaDeProductos(int number = 0)
        {
            List<Producto> productos;
            if (number == 0)
            {
                productos = dbContext.Productos.ToList();
            }
            else
            {
                productos = (from p in dbContext.Productos orderby p.SkuID descending select p).Take(number).ToList();
            }

            return PartialView("_GaleriaDeProductos", productos);
        }



        // GET: Producto/Detalles/5
        public ActionResult Detalles(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Producto producto = dbContext.Productos.Find(id);
            if (producto == null)
            {
                return HttpNotFound();
            }
            return View(producto);
        }



        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                dbContext.Dispose();
            }
            base.Dispose(disposing);
        }




        public FileContentResult ObtieneFotoProducto(int skuId)
        {
            //Obtiene la foto del skuId solicitado
            Producto producto = dbContext.Productos.Find(skuId);
            if (producto != null)
            {
                return File(producto.FotoArchivo, producto.ImagenTipo);
            }
            else
            {
                return null;
            }
        }
        

    }
}
