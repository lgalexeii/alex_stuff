﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CarritoComprasProy.Models
{
    public class CuentaUsuario
    {
        [Key]
        public int UsuarioId { get; set; }

        [Required]
        public string Usuario { get; set; }

        [DataType (DataType.Password)]
        public string Password { get; set; }

    }


    public class Login
    {
        [Required]
        public string Usuario { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Display(Name = "¿Recordarme?")]
        public bool Recordarme { get; set; }
    }

    public class Registro
    {
        [Required]
        public string Usuario { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirmar password")]
        [Compare("Password", ErrorMessage = "El Password y la confirmacion no coinciden")]
        public string ConfirmarPassword { get; set; }
    }
}