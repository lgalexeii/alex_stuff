﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;


namespace CarritoComprasProy.Models
{
    public class ProductoCatalogoContext: DbContext
    {

        public ProductoCatalogoContext() : base()
        {
            this.Database.CommandTimeout = 180;
        }

        public DbSet<Producto> Productos { get; set; }
        public DbSet<ComentariosProducto> CommentariosProductos { get; set; }

        public DbSet<ArticuloCarrito> ArticulosCarrito { get; set; }
        public DbSet<CompraUsuario> ComprasUsuario { get; set; }
    }
}