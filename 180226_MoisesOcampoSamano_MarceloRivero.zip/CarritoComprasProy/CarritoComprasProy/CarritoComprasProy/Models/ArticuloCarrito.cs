﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CarritoComprasProy.Models
{
    public class ArticuloCarrito
    {
        [Key]
        public int NumOrdenId { get; set; }
        public int SkuID { get; set; }
        public string Usuario { get; set; }
        public int cantidad { get; set; }
    }
}