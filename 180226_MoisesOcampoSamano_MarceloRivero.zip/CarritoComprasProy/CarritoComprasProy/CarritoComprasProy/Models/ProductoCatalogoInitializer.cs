﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Web;

namespace CarritoComprasProy.Models
{
    //public class ProductoCatalogoInitializer : CreateDatabaseIfNotExists<ProductoCatalogoContext>
    public class ProductoCatalogoInitializer : DropCreateDatabaseAlways<ProductoCatalogoContext>
    {

        private byte[] ObtenerFotosProductos(string path)
        {
            FileStream fileOnDisk = new FileStream(HttpRuntime.AppDomainAppPath + path, FileMode.Open);
            byte[] fileBytes;
            using (BinaryReader br = new BinaryReader(fileOnDisk))
            {
                fileBytes = br.ReadBytes((int)fileOnDisk.Length);
            }
            return fileBytes;
        }




        protected override void Seed(ProductoCatalogoContext context)
        {
            base.Seed(context);

            //Crear Productos
            var productos = new List<Producto>
            {
                new Producto {
                    SkuID=1,
                    Titulo = "Caja Herramientas",
                    Descripcion = "Caja Para Herramientas de 56 Centimetros",
                    Precio = 326.99M,
                    Existencias=1,
                    FotoArchivo=ObtenerFotosProductos("\\Imagenes\\1_Caja_Herramientas_56cm.jpg"),
                    ImagenTipo="image/jpeg"
                },


                new Producto {
                    SkuID=2,
                    Titulo = "Caja Herramientas Rodante",
                    Descripcion = "Caja Para Herramientas De varios compartimentos y llantas para facil traslado",
                    Precio = 1978.99M,
                    Existencias=19,
                    FotoArchivo=ObtenerFotosProductos("\\Imagenes\\2_Caja_herramientas_rodante.jpg"),
                    ImagenTipo="image/jpeg"
                },

                new Producto {
                    SkuID=3,
                    Titulo = "Kit Herramientas",
                    Descripcion = "Kit de varias Herramientas Basicas para diferentes usos",
                    Precio = 789.53M,
                    Existencias=44,
                    FotoArchivo=ObtenerFotosProductos("\\Imagenes\\3_Kit_Herramientas.jpg"),
                    ImagenTipo="image/jpeg"
                },

                new Producto {
                    SkuID=4,
                    Titulo = "Llaves Españolas 1",
                    Descripcion = "Kit de 9 Llaves Españolas Reforzadas",
                    Precio = 684.22M,
                    Existencias=14,
                    FotoArchivo=ObtenerFotosProductos("\\Imagenes\\4_Llaves_españolas_Kit1.jpg"),
                    ImagenTipo="image/jpeg"
                },

                new Producto {
                    SkuID=5,
                    Titulo = "Llaves Españolas 2",
                    Descripcion = "Kit de 5 Llaves Españolas",
                    Precio = 684.22M,
                    Existencias=14,
                    FotoArchivo=ObtenerFotosProductos("\\Imagenes\\5_Llaves_españolas_Kit2.jpg"),
                    ImagenTipo="image/jpeg"
                },

                new Producto {
                    SkuID=6,
                    Titulo = "Martillo Joyero",
                    Descripcion = "Martillo liviano con mango de reforzado para joyeria",
                    Precio = 323.12M,
                    Existencias=19,
                    FotoArchivo=ObtenerFotosProductos("\\Imagenes\\6_martillo_joyero.jpg"),
                    ImagenTipo="image/jpeg"
                },

                new Producto {
                    SkuID=7,
                    Titulo = "Martillo",
                    Descripcion = "Martillo Con Mango de Madera",
                    Precio = 364.21M,
                    Existencias=44,
                    FotoArchivo=ObtenerFotosProductos("\\Imagenes\\7_martillo_mango_madera.jpg"),
                    ImagenTipo="image/jpeg"
                },

                new Producto {
                    SkuID=8,
                    Titulo = "Matraca",
                    Descripcion = "Matraca con dados, diferente medida",
                    Precio = 474.20M,
                    Existencias=4,
                    FotoArchivo=ObtenerFotosProductos("\\Imagenes\\8_matraca_Dados_1.jpg"),
                    ImagenTipo="image/jpeg"
                },

                new Producto {
                    SkuID=9,
                    Titulo = "Multimetro",
                    Descripcion = "Multimetro Digital, con diferentes funciones",
                    Precio = 1024.99M,
                    Existencias=12,
                    FotoArchivo=ObtenerFotosProductos("\\Imagenes\\9_multimetro_digital.jpg"),
                    ImagenTipo="image/jpeg"
                },

                new Producto {
                    SkuID=10,
                    Titulo = "Multimetro economico",
                    Descripcion = "Multimetro digital con funciones basicas",
                    Precio = 129.99M,
                    Existencias=21,
                    FotoArchivo=ObtenerFotosProductos("\\Imagenes\\10_multimetro_economico.jpg"),
                    ImagenTipo="image/jpeg"
                },

                new Producto {
                    SkuID=11,
                    Titulo = "Herramientas Varias",
                    Descripcion = "Set de Herramientas multiusos con estuche",
                    Precio = 1989.99M,
                    Existencias=11,
                    FotoArchivo=ObtenerFotosProductos("\\Imagenes\\11_Set_Herramientas_multiusos.jpg"),
                    ImagenTipo="image/jpeg"
                },

                new Producto {
                    SkuID=12,
                    Titulo = "Taladro Bosch",
                    Descripcion = "Taladro Industrial Marca Bosch de varias velocidades con rotomartillo",
                    Precio = 3213.59M,
                    Existencias=5,
                    FotoArchivo=ObtenerFotosProductos("\\Imagenes\\12_taladro_industrial_bosch.jpg"),
                    ImagenTipo="image/jpeg"
                },

                new Producto {
                    SkuID=13,
                    Titulo = "Taladro Skil",
                    Descripcion = "Taladro Marca Skil de varias velocidades con rotomartillo, para tareas del hogar",
                    Precio = 623.59M,
                    Existencias=15,
                    FotoArchivo=ObtenerFotosProductos("\\Imagenes\\13_taladro_skill_rotomartillo.jpg"),
                    ImagenTipo="image/jpeg"
                },

                new Producto {
                    SkuID=14,
                    Titulo = "Taladro de Banco",
                    Descripcion = "Taladro Industrial de Banco con motor de 1/3 Caballos de fuerza.",
                    Precio = 7899.14M,
                    Existencias=15,
                    FotoArchivo=ObtenerFotosProductos("\\Imagenes\\14_taladro-de-banco.jpg"),
                    ImagenTipo="image/jpeg"
                }
            };
            productos.ForEach(s => context.Productos.Add(s));
            context.SaveChanges();

            
            //Crear Comentarios
            var ComentariosProductos = new List<ComentariosProducto>
            {
                new ComentariosProducto {
                    SkuID = 1,
                    Usuario = "Pablo",
                    Asunto = "Valoracion de herramienta",
                    Body = "Esta hecha de muy buen material, es espaciosa y muy resistente. La recomiendo para guardar tu herramienta"
                },
                new ComentariosProducto {
                    SkuID = 10,
                    Usuario = "Juan Perez",
                    Asunto = "Es muy simple",
                    Body = "Trae las funciones basicas y sirve para cosas sencillas pero recomiendo uno con mayor funcionalidad"
                },
                new ComentariosProducto {
                    SkuID = 10,
                    Usuario = "Juan Camaney",
                    Asunto = "Funciona para trabajos sencillos",
                    Body = "Muy portable... se puede llevar a donde sea ya que es pequeño, aunque solo trae lo basico"
                },

                new ComentariosProducto {
                    SkuID = 10,
                    Usuario = "Pancho Lopez",
                    Asunto = "Esta muy basico",
                    Body = "No lo recomiendo, prefiero uno con mayor funcionalidad, ademas los cables son muy delgados. No lo recomiendo, prefiero uno con mayor funcionalidad, ademas los cables son muy delgados .No lo recomiendo, prefiero uno con mayor funcionalidad, ademas los cables son muy delgados"
                },

                new ComentariosProducto {
                    SkuID = 13,
                    Usuario = "Juan Perez",
                    Asunto = "Funciona muy bien",
                    Body = "Es muy util para trabajos caseros, funciona muy bien, el precio es accesible"
                }
            };
            ComentariosProductos.ForEach(s => context.CommentariosProductos.Add(s));
            context.SaveChanges();
        }
    }
}