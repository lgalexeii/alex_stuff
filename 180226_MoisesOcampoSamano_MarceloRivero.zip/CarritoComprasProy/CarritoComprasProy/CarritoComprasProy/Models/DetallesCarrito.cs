﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CarritoComprasProy.Models
{
    public class DetallesCarrito
    {
        [Key]
        public int NumOrdenId { get; set; }
        public int SkuID { get; set; }
        public String Usuario { get; set; }
        [DisplayName("Cantidad")]
        //[Range(1,10, ErrorMessage ="Solo puede comprar entre 1 y 10 unidades")]
        public int cantidad { get; set; }

        //Descripcion Corta del Articulo
        [MaxLength]
        public string Titulo { get; set; }

        //precio del Articulo
        [DisplayName("Precio por unidad")]
        public decimal Precio { get; set; }

        //Stock en inventario
        public int Existencias { get; set; }

        [DisplayName("Foto")]
        public byte[] FotoArchivo { get; set; }

        public decimal Total { get; set; }

        [Required]
        public string CuponCompra { get; set; }
    }
}