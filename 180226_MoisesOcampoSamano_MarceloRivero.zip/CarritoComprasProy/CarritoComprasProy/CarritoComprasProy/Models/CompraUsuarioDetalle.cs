﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CarritoComprasProy.Models
{
    public class CompraUsuarioDetalle: CompraUsuario
    {
        //Descripcion Corta del Articulo
        [MaxLength]
        public string Titulo { get; set; }

        [DisplayName("Foto")]
        public byte[] FotoArchivo { get; set; }

    }
}