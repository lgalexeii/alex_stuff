﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CarritoComprasProy.Models
{
    public class Producto
    {

        //LLave primaria
        [Key]
        public int SkuID { get; set; }

        //Descripcion Corta del Articulo
        [MaxLength]
        public string Titulo { get; set; }

        //Descipcion mas detallada del articulo
        [DataType(DataType.MultilineText)]
        public string Descripcion { get; set; }

        //precio del Articulo
        public decimal Precio { get; set; }

        //Stock en inventario
        public int Existencias { get; set; }

        [DisplayName("Foto")]
        public byte[] FotoArchivo { get; set; }

        public string ImagenTipo { get; set; }

        public virtual ICollection<ComentariosProducto> CommentariosProducto { get; set; }
    }
}