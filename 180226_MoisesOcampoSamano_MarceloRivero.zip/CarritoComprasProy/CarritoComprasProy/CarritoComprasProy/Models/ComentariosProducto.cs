﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace CarritoComprasProy.Models
{
    /// <summary>
    /// Esta Clase sirve para agregar comentarios de los compradores sobre los productos en linea, basados en la experiencias de compra
    /// </summary>
    public class ComentariosProducto
    {
        [Key]
        public int ComentarioID { get; set; }
        public int SkuID { get; set; }
        public string Usuario { get; set; }
        [Required]
        [StringLength(250)]
        public string Asunto { get; set; }
        [DataType(DataType.MultilineText)]
        [DisplayName("Comentario")]
        public string Body { get; set; }

        public virtual Producto producto { get; set; }

    }
}