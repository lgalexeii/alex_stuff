﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CarritoComprasProy.Models
{
    public class CompraUsuario
    {

        [Key]
        [DisplayName("Folio de Compra")]
        public int NumCompraId { get; set; }
        public int SkuID { get; set; }
        public string Usuario { get; set; }
        public int Cantidad { get; set; }
        public decimal PrecioUnidad { get; set; }
        public decimal Total { get; set; }
        [DisplayName("Cupon de Compra")]
        public string CuponCompra { get; set; }

        [DisplayName("Fecha de Compra")]
        public string FechaCompra { get; set; }
    }
}