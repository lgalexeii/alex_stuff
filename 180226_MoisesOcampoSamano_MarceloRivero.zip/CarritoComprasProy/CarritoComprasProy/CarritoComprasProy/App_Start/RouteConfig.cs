﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace CarritoComprasProy
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.MapRoute(
               name: "AgregaArticuloCarrito",
               url: "Producto/AgregarArticuloCarrito/{id}",
               defaults: new { controller = "Carrito", action = "AgregarArticuloCarrito", id = UrlParameter.Optional }
           );

           

            routes.MapRoute(
               name: "ComprarArticulo",
               url: "Carrito/ComprarArticulo/{id}",
               defaults: new { controller = "Compras", action = "ComprarArticulo", id = UrlParameter.Optional }
           );

            routes.MapRoute(
               name: "CrearComentario",
               url: "Compras/CrearComentario/{id}",
               defaults: new { controller = "Comentarios", action = "CrearComentario", id = UrlParameter.Optional }
           );


            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");            

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );

           
        }
    }
}
